<?php 
/**
 * Drainage_noc_jal_oc Page Controller
 * @category  Controller
 */
class Drainage_noc_jal_ocController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "drainage_noc_jal_oc";
	}
	/**
     * List page records
     * @param $fieldname (filter record by a field) 
     * @param $fieldvalue (filter field value)
     * @return BaseView
     */
	function index($fieldname = null , $fieldvalue = null){
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$fields = array("id", 
			"status", 
			"application_no", 
			"applicant_name", 
			"house_building_society_name", 
			"house_or_block_number", 
			"wing", 
			"floor", 
			"road_name", 
			"place_or_division_or_village", 
			"taluka", 
			"zone_value", 
			"election_ward_no_value", 
			"mobile_no", 
			"email", 
			"architect_name", 
			"property_type_value", 
			"computarized_property_no", 
			"property_survey_no_or_city_survey_no", 
			"mouje_gaon_name", 
			"road_name_for_property", 
			"place_division_gaon_for_property", 
			"property_taluka", 
			"pincode_for_property", 
			"zone_property_value", 
			"property_type_as_per_application_value", 
			"is_construction_commence_ceriticate_available", 
			"commence_ceriticate_number", 
			"commence_ceriticate_date", 
			"property_usage", 
			"property_usage_type_value", 
			"upload_cc_certificate", 
			"upload_architech_affidavit", 
			"upload_construction_permission_and_cerified_map_copy", 
			"upload_architect_or_project_consultant_report", 
			"upload_property_location_map", 
			"upload_noc_copy_given_for_construction_permission", 
			"upload_map_prepared_by_licensed_plumber", 
			"rec_id", 
			"user_id", 
			"date", 
			"certificate", 
			"timestamp", 
			"paid", 
			"demand", 
			"inspection", 
			"commencement_number");
		$pagination = $this->get_pagination(MAX_RECORD_COUNT); // get current pagination e.g array(page_number, page_limit)
	#Statement to execute before list record
	if(USER_ROLE==2){
    $db->where("user_id",USER_ID);
}
if(USER_ROLE==3){
    $db->where("zone_value",explode(",",get_active_user("zone_id")),"IN");
    $db->where("(status>=1 or status='Completed' or status='Rejected')");
}
if(USER_ROLE==4){
    $db->where("zone_value",explode(",",get_active_user("zone_id")),"IN");
    $db->where("(status>=2 or status='Completed' or status='Rejected')");
}
if(USER_ROLE==5){
    $db->where("zone_value",explode(",",get_active_user("zone_id")),"IN");
    $db->where("(status>=3 or status='Completed' or status='Rejected') ");
}
	# End of before list statement
		//search table record
		if(!empty($request->search)){
			$text = trim($request->search); 
			$search_condition = "(
				drainage_noc_jal_oc.id LIKE ? OR 
				drainage_noc_jal_oc.status LIKE ? OR 
				drainage_noc_jal_oc.application_no LIKE ? OR 
				drainage_noc_jal_oc.applicant_name LIKE ? OR 
				drainage_noc_jal_oc.house_building_society_name LIKE ? OR 
				drainage_noc_jal_oc.house_or_block_number LIKE ? OR 
				drainage_noc_jal_oc.wing LIKE ? OR 
				drainage_noc_jal_oc.floor LIKE ? OR 
				drainage_noc_jal_oc.road_name LIKE ? OR 
				drainage_noc_jal_oc.place_or_division_or_village LIKE ? OR 
				drainage_noc_jal_oc.taluka LIKE ? OR 
				drainage_noc_jal_oc.zone_value LIKE ? OR 
				drainage_noc_jal_oc.election_ward_no_value LIKE ? OR 
				drainage_noc_jal_oc.mobile_no LIKE ? OR 
				drainage_noc_jal_oc.email LIKE ? OR 
				drainage_noc_jal_oc.architect_name LIKE ? OR 
				drainage_noc_jal_oc.property_type_value LIKE ? OR 
				drainage_noc_jal_oc.computarized_property_no LIKE ? OR 
				drainage_noc_jal_oc.property_survey_no_or_city_survey_no LIKE ? OR 
				drainage_noc_jal_oc.mouje_gaon_name LIKE ? OR 
				drainage_noc_jal_oc.road_name_for_property LIKE ? OR 
				drainage_noc_jal_oc.place_division_gaon_for_property LIKE ? OR 
				drainage_noc_jal_oc.property_taluka LIKE ? OR 
				drainage_noc_jal_oc.pincode_for_property LIKE ? OR 
				drainage_noc_jal_oc.zone_property_value LIKE ? OR 
				drainage_noc_jal_oc.property_type_as_per_application_value LIKE ? OR 
				drainage_noc_jal_oc.is_construction_commence_ceriticate_available LIKE ? OR 
				drainage_noc_jal_oc.commence_ceriticate_number LIKE ? OR 
				drainage_noc_jal_oc.commence_ceriticate_date LIKE ? OR 
				drainage_noc_jal_oc.property_usage LIKE ? OR 
				drainage_noc_jal_oc.property_usage_type_value LIKE ? OR 
				drainage_noc_jal_oc.upload_cc_certificate LIKE ? OR 
				drainage_noc_jal_oc.upload_architech_affidavit LIKE ? OR 
				drainage_noc_jal_oc.upload_construction_permission_and_cerified_map_copy LIKE ? OR 
				drainage_noc_jal_oc.upload_architect_or_project_consultant_report LIKE ? OR 
				drainage_noc_jal_oc.upload_property_location_map LIKE ? OR 
				drainage_noc_jal_oc.upload_noc_copy_given_for_construction_permission LIKE ? OR 
				drainage_noc_jal_oc.upload_map_prepared_by_licensed_plumber LIKE ? OR 
				drainage_noc_jal_oc.rec_id LIKE ? OR 
				drainage_noc_jal_oc.user_id LIKE ? OR 
				drainage_noc_jal_oc.date LIKE ? OR 
				drainage_noc_jal_oc.certificate LIKE ? OR 
				drainage_noc_jal_oc.timestamp LIKE ? OR 
				drainage_noc_jal_oc.paid LIKE ? OR 
				drainage_noc_jal_oc.demand LIKE ? OR 
				drainage_noc_jal_oc.inspection LIKE ? OR 
				drainage_noc_jal_oc.commencement_number LIKE ?
			)";
			$search_params = array(
				"%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%","%$text%"
			);
			//setting search conditions
			$db->where($search_condition, $search_params);
			 //template to use when ajax search
			$this->view->search_template = "drainage_noc_jal_oc/search.php";
		}
		if(!empty($request->orderby)){
			$orderby = $request->orderby;
			$ordertype = (!empty($request->ordertype) ? $request->ordertype : ORDER_TYPE);
			$db->orderBy($orderby, $ordertype);
		}
		else{
			$db->orderBy("drainage_noc_jal_oc.id", ORDER_TYPE);
		}
		if($fieldname){
			$db->where($fieldname , $fieldvalue); //filter by a single field name
		}
		$tc = $db->withTotalCount();
		$records = $db->get($tablename, $pagination, $fields);
		$records_count = count($records);
		$total_records = intval($tc->totalCount);
		$page_limit = $pagination[1];
		$total_pages = ceil($total_records / $page_limit);
		if(	!empty($records)){
			foreach($records as &$record){
				$record['date'] = human_date($record['date']);
$record['timestamp'] = human_datetime($record['timestamp']);
			}
		}
		$data = new stdClass;
		$data->records = $records;
		$data->record_count = $records_count;
		$data->total_records = $total_records;
		$data->total_page = $total_pages;
		if($db->getLastError()){
			$this->set_page_error();
		}
		$page_title = $this->view->page_title = "Drainage Noc Jal Oc";
		$this->render_view("drainage_noc_jal_oc/list.php", $data); //render the full page
	}
	/**
     * View record detail 
	 * @param $rec_id (select record by table primary key) 
     * @param $value value (select record by value of field name(rec_id))
     * @return BaseView
     */
	function view($rec_id = null, $value = null){
		$request = $this->request;
		$db = $this->GetModel();
		$rec_id = $this->rec_id = urldecode($rec_id);
		$tablename = $this->tablename;
		$fields = array("id", 
			"application_type_id", 
			"application_type_value", 
			"applicant_surname", 
			"applicant_name", 
			"applicant_father_or_spouse_name", 
			"title", 
			"house_building_society_name", 
			"house_or_block_number", 
			"wing", 
			"floor", 
			"road_name", 
			"place_or_division_or_village", 
			"taluka", 
			"pincode", 
			"zone_id", 
			"zone_value", 
			"election_ward_no_id", 
			"election_ward_no_value", 
			"mobile_no", 
			"email", 
			"title_property", 
			"property_type_id", 
			"property_type_value", 
			"computarized_property_no", 
			"title_for_application_related_information", 
			"property_survey_no_or_city_survey_no", 
			"mouje_gaon_name", 
			"road_name_for_property", 
			"place_division_gaon_for_property", 
			"pincode_for_property", 
			"zone_property_id", 
			"zone_property_value", 
			"property_type_as_per_application_id", 
			"property_type_as_per_application_value", 
			"is_construction_commence_ceriticate_available", 
			"commence_ceriticate_number", 
			"commence_ceriticate_date", 
			"property_usage", 
			"property_usage_type_id", 
			"property_usage_type_value", 
			"upload_architech_affidavit", 
			"upload_construction_permission_and_cerified_map_copy", 
			"upload_architect_or_project_consultant_report", 
			"upload_property_location_map", 
			"upload_noc_copy_given_for_construction_permission", 
			"upload_map_prepared_by_licensed_plumber", 
			"rec_id", 
			"user_id", 
			"date", 
			"architect_name", 
			"hissa_number", 
			"timestamp", 
			"status", 
			"certificate", 
			"paid", 
			"property_taluka", 
			"upload_mep_consultant_or_architect_declaration", 
			"application_no", 
			"demand", 
			"inspection", 
			"commencement_number", 
			"upload_cc_certificate");
		if($value){
			$db->where($rec_id, urldecode($value)); //select record based on field name
		}
		else{
			$db->where("drainage_noc_jal_oc.id", $rec_id);; //select record based on primary key
		}
		$record = $db->getOne($tablename, $fields );
		if($record){
			$page_title = $this->view->page_title = "View  Drainage Noc Jal Oc";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		}
		else{
			if($db->getLastError()){
				$this->set_page_error();
			}
			else{
				$this->set_page_error("No record found");
			}
		}
		return $this->render_view("drainage_noc_jal_oc/view.php", $record);
	}
	/**
     * Insert new record to the database table
	 * @param $formdata array() from $_POST
     * @return BaseView
     */
	function add($formdata = null){
		if($formdata){
			$db = $this->GetModel();
			$tablename = $this->tablename;
			$request = $this->request;
			//fillable fields
			$fields = $this->fields = array("commencement_number","applicant_name","house_building_society_name","house_or_block_number","floor","place_or_division_or_village","taluka","zone_id","mobile_no","email","architect_name","property_type_id","property_survey_no_or_city_survey_no","mouje_gaon_name","place_division_gaon_for_property","property_taluka","zone_property_id","property_type_as_per_application_id","property_usage","property_usage_type_id","wing","road_name","election_ward_no_id","computarized_property_no","road_name_for_property","pincode_for_property","is_construction_commence_ceriticate_available","commence_ceriticate_number","commence_ceriticate_date","upload_architech_affidavit","upload_construction_permission_and_cerified_map_copy","upload_architect_or_project_consultant_report","upload_property_location_map","upload_noc_copy_given_for_construction_permission","upload_map_prepared_by_licensed_plumber","user_id","date","status");
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'commencement_number' => 'required',
				'applicant_name' => 'required',
				'house_building_society_name' => 'required',
				'house_or_block_number' => 'required',
				'floor' => 'required',
				'place_or_division_or_village' => 'required',
				'taluka' => 'required',
				'zone_id' => 'required',
				'mobile_no' => 'required|numeric|max_numeric,9999999999|min_numeric,1000000000',
				'email' => 'required|valid_email',
				'architect_name' => 'required',
				'property_type_id' => 'required',
				'property_survey_no_or_city_survey_no' => 'required',
				'mouje_gaon_name' => 'required',
				'place_division_gaon_for_property' => 'required',
				'property_taluka' => 'required',
				'zone_property_id' => 'required',
				'property_type_as_per_application_id' => 'required',
				'property_usage' => 'required',
				'property_usage_type_id' => 'required',
				'wing' => 'required',
				'road_name' => 'required',
				'election_ward_no_id' => 'required',
				'computarized_property_no' => 'required',
				'road_name_for_property' => 'required',
				'pincode_for_property' => 'required|numeric',
				'is_construction_commence_ceriticate_available' => 'required',
				'upload_architech_affidavit' => 'required',
				'upload_construction_permission_and_cerified_map_copy' => 'required',
				'upload_architect_or_project_consultant_report' => 'required',
				'upload_property_location_map' => 'required',
				'upload_noc_copy_given_for_construction_permission' => 'required',
				'upload_map_prepared_by_licensed_plumber' => 'required',
			);
			$this->sanitize_array = array(
				'commencement_number' => 'sanitize_string',
				'applicant_name' => 'sanitize_string',
				'house_building_society_name' => 'sanitize_string',
				'house_or_block_number' => 'sanitize_string',
				'floor' => 'sanitize_string',
				'place_or_division_or_village' => 'sanitize_string',
				'taluka' => 'sanitize_string',
				'zone_id' => 'sanitize_string',
				'mobile_no' => 'sanitize_string',
				'email' => 'sanitize_string',
				'architect_name' => 'sanitize_string',
				'property_type_id' => 'sanitize_string',
				'property_survey_no_or_city_survey_no' => 'sanitize_string',
				'mouje_gaon_name' => 'sanitize_string',
				'place_division_gaon_for_property' => 'sanitize_string',
				'property_taluka' => 'sanitize_string',
				'zone_property_id' => 'sanitize_string',
				'property_type_as_per_application_id' => 'sanitize_string',
				'property_usage' => 'sanitize_string',
				'property_usage_type_id' => 'sanitize_string',
				'wing' => 'sanitize_string',
				'road_name' => 'sanitize_string',
				'election_ward_no_id' => 'sanitize_string',
				'computarized_property_no' => 'sanitize_string',
				'road_name_for_property' => 'sanitize_string',
				'pincode_for_property' => 'sanitize_string',
				'is_construction_commence_ceriticate_available' => 'sanitize_string',
				'commence_ceriticate_number' => 'sanitize_string',
				'commence_ceriticate_date' => 'sanitize_string',
				'upload_architech_affidavit' => 'sanitize_string',
				'upload_construction_permission_and_cerified_map_copy' => 'sanitize_string',
				'upload_architect_or_project_consultant_report' => 'sanitize_string',
				'upload_property_location_map' => 'sanitize_string',
				'upload_noc_copy_given_for_construction_permission' => 'sanitize_string',
				'upload_map_prepared_by_licensed_plumber' => 'sanitize_string',
			);
			$this->filter_vals = true; //set whether to remove empty fields
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			$modeldata['user_id'] = USER_ID;
$modeldata['date'] = date_now();
$modeldata['status'] = "1";
			if($this->validated()){
			    
			    
    $db->where("user_id",USER_ID);
    $rec=$db->getOne("drainage_noc_jal_cc");
    if(isset($rec['id'])){
        
    $modeldata['upload_cc_certificate']=$rec['certificate'];
    }
    
				$rec_id = $this->rec_id = $db->insert($tablename, $modeldata);
				if($rec_id){
				    
  file_get_contents("https://singlewindowsystemkdmc.in/api/progress/$tablename/".USER_NAME."/pending/".urlencode($_SESSION['appl_type']));
$db->insert("application_mapping",["db_name"=>$tablename,"rec_id"=>$rec_id,"appl_type"=>$_SESSION['appl_type']]);
		# Statement to execute after adding record
		//execute sql statement and return a single field value
$params = array($modeldata['election_ward_no_id']);
$value  = $db->rawQueryValue("SELECT ward_name FROM m_election_ward WHERE id = ?", $params);
$table_data = array(
    "election_ward_no_value" => $value[0]
);
$db->where("id", $rec_id);
$bool = $db->update("drainage_noc_jal_oc", $table_data);
//execute sql statement and return a single field value
$params1 = array($modeldata['zone_id']);
$value1  = $db->rawQueryValue("SELECT zone FROM zone_master WHERE id = ?", $params1);
$table_data1 = array(
    "zone_value" => $value1[0]
);
$db->where("id", $rec_id);
$bool = $db->update("drainage_noc_jal_oc", $table_data1);
//execute sql statement and return a single field value
$params2 = array($modeldata['property_type_id']);
$value2  = $db->rawQueryValue("SELECT property_type FROM master_property_type_jalmal WHERE id = ?", $params2);
$table_data2 = array(
    "property_type_value" => $value2[0]
);
$db->where("id", $rec_id);
$bool = $db->update("drainage_noc_jal_oc", $table_data2);
//execute sql statement and return a single field value
$params3 = array($modeldata['zone_property_id']);
$value3  = $db->rawQueryValue("SELECT zone FROM zone_master WHERE id = ?", $params3);
$table_data3 = array(
    "zone_property_value" => $value3[0]
);
$db->where("id", $rec_id);
$bool = $db->update("drainage_noc_jal_oc", $table_data3);
//execute sql statement and return a single field value
$params4 = array($modeldata['property_type_as_per_application_id']);
$value4  = $db->rawQueryValue("SELECT property_type FROM master_property_type_jalmal WHERE id = ?", $params4);
$table_data4 = array(
    "property_type_as_per_application_value" => $value4[0]
);
$db->where("id", $rec_id);
$bool = $db->update("drainage_noc_jal_oc", $table_data4);
//execute sql statement and return a single field value
$params5 = array($modeldata['property_usage_type_id']);
$value5  = $db->rawQueryValue("SELECT property_usage FROM master_property_usage WHERE id = ?", $params5);
$table_data5 = array(
    "property_usage_type_value" => $value5[0]
);
$db->where("id", $rec_id);
$bool = $db->update("drainage_noc_jal_oc", $table_data5);
$application_id = $rec_id; // now you have the actual application ID
if (date("m") >= 4) {
    $yr = date("y") . "-" . (date("y") + 1);
} else {
    $yr = (date("y") - 1) . "-" . date("y");
}
$receipt_no = "KDMC/DRAIN/JAL_OC/" . $application_id . "/" . $yr;
// Update the row with receipt_no
$db->where("id", $application_id);
$db->update("drainage_noc_jal_oc", ["application_no" => $receipt_no]);
		# End of after add statement
					$this->set_flash_msg("Record added successfully", "success");
					return	$this->redirect("drainage_noc_jal_oc");
				}
				else{
					$this->set_page_error();
				}
			}
		}
		$page_title = $this->view->page_title = "Add New Drainage Noc Jal Oc";
		$this->render_view("drainage_noc_jal_oc/add.php");
	}
	/**
     * Update table record with formdata
	 * @param $rec_id (select record by table primary key)
	 * @param $formdata array() from $_POST
     * @return array
     */
	function edit($rec_id = null, $formdata = null){
		$request = $this->request;
		$db = $this->GetModel();
		$this->rec_id = $rec_id;
		$tablename = $this->tablename;
		 //editable fields
		$fields = $this->fields = array("id","commencement_number","applicant_name","house_building_society_name","house_or_block_number","floor","place_or_division_or_village","taluka","zone_id","mobile_no","email","architect_name","property_type_id","property_survey_no_or_city_survey_no","mouje_gaon_name","place_division_gaon_for_property","property_taluka","zone_property_id","property_type_as_per_application_id","property_usage","property_usage_type_id","wing","road_name","election_ward_no_id","computarized_property_no","road_name_for_property","pincode_for_property","is_construction_commence_ceriticate_available","commence_ceriticate_number","commence_ceriticate_date","upload_architech_affidavit","upload_construction_permission_and_cerified_map_copy","upload_architect_or_project_consultant_report","upload_property_location_map","upload_noc_copy_given_for_construction_permission","upload_map_prepared_by_licensed_plumber","user_id","date","status");
		if($formdata){
			$postdata = $this->format_request_data($formdata);
			$this->rules_array = array(
				'commencement_number' => 'required',
				'applicant_name' => 'required',
				'house_building_society_name' => 'required',
				'house_or_block_number' => 'required',
				'floor' => 'required',
				'place_or_division_or_village' => 'required',
				'taluka' => 'required',
				'zone_id' => 'required',
				'mobile_no' => 'required|numeric|max_numeric,9999999999|min_numeric,1000000000',
				'email' => 'required|valid_email',
				'architect_name' => 'required',
				'property_type_id' => 'required',
				'property_survey_no_or_city_survey_no' => 'required',
				'mouje_gaon_name' => 'required',
				'place_division_gaon_for_property' => 'required',
				'property_taluka' => 'required',
				'zone_property_id' => 'required',
				'property_type_as_per_application_id' => 'required',
				'property_usage' => 'required',
				'property_usage_type_id' => 'required',
				'wing' => 'required',
				'road_name' => 'required',
				'election_ward_no_id' => 'required',
				'computarized_property_no' => 'required',
				'road_name_for_property' => 'required',
				'pincode_for_property' => 'required|numeric',
				'is_construction_commence_ceriticate_available' => 'required',
				'upload_architech_affidavit' => 'required',
				'upload_construction_permission_and_cerified_map_copy' => 'required',
				'upload_architect_or_project_consultant_report' => 'required',
				'upload_property_location_map' => 'required',
				'upload_noc_copy_given_for_construction_permission' => 'required',
				'upload_map_prepared_by_licensed_plumber' => 'required',
			);
			$this->sanitize_array = array(
				'commencement_number' => 'sanitize_string',
				'applicant_name' => 'sanitize_string',
				'house_building_society_name' => 'sanitize_string',
				'house_or_block_number' => 'sanitize_string',
				'floor' => 'sanitize_string',
				'place_or_division_or_village' => 'sanitize_string',
				'taluka' => 'sanitize_string',
				'zone_id' => 'sanitize_string',
				'mobile_no' => 'sanitize_string',
				'email' => 'sanitize_string',
				'architect_name' => 'sanitize_string',
				'property_type_id' => 'sanitize_string',
				'property_survey_no_or_city_survey_no' => 'sanitize_string',
				'mouje_gaon_name' => 'sanitize_string',
				'place_division_gaon_for_property' => 'sanitize_string',
				'property_taluka' => 'sanitize_string',
				'zone_property_id' => 'sanitize_string',
				'property_type_as_per_application_id' => 'sanitize_string',
				'property_usage' => 'sanitize_string',
				'property_usage_type_id' => 'sanitize_string',
				'wing' => 'sanitize_string',
				'road_name' => 'sanitize_string',
				'election_ward_no_id' => 'sanitize_string',
				'computarized_property_no' => 'sanitize_string',
				'road_name_for_property' => 'sanitize_string',
				'pincode_for_property' => 'sanitize_string',
				'is_construction_commence_ceriticate_available' => 'sanitize_string',
				'commence_ceriticate_number' => 'sanitize_string',
				'commence_ceriticate_date' => 'sanitize_string',
				'upload_architech_affidavit' => 'sanitize_string',
				'upload_construction_permission_and_cerified_map_copy' => 'sanitize_string',
				'upload_architect_or_project_consultant_report' => 'sanitize_string',
				'upload_property_location_map' => 'sanitize_string',
				'upload_noc_copy_given_for_construction_permission' => 'sanitize_string',
				'upload_map_prepared_by_licensed_plumber' => 'sanitize_string',
			);
			$modeldata = $this->modeldata = $this->validate_form($postdata);
			$modeldata['user_id'] = USER_ID;
$modeldata['date'] = date_now();
$modeldata['status'] = "1";
			if($this->validated()){
				$db->where("drainage_noc_jal_oc.id", $rec_id);;
				$bool = $db->update($tablename, $modeldata);
				$numRows = $db->getRowCount(); //number of affected rows. 0 = no record field updated
				if($bool && $numRows){
					$this->set_flash_msg("Record updated successfully", "success");
					return $this->redirect("drainage_noc_jal_oc");
				}
				else{
					if($db->getLastError()){
						$this->set_page_error();
					}
					elseif(!$numRows){
						//not an error, but no record was updated
						$page_error = "No record updated";
						$this->set_page_error($page_error);
						$this->set_flash_msg($page_error, "warning");
						return	$this->redirect("drainage_noc_jal_oc");
					}
				}
			}
		}
		$db->where("drainage_noc_jal_oc.id", $rec_id);;
		$data = $db->getOne($tablename, $fields);
		$page_title = $this->view->page_title = "Edit  Drainage Noc Jal Oc";
		if(!$data){
			$this->set_page_error();
		}
		return $this->render_view("drainage_noc_jal_oc/edit.php", $data);
	}
	/**
     * Delete record from the database
	 * Support multi delete by separating record id by comma.
     * @return BaseView
     */
	function delete($rec_id = null){
		Csrf::cross_check();
		$request = $this->request;
		$db = $this->GetModel();
		$tablename = $this->tablename;
		$this->rec_id = $rec_id;
		//form multiple delete, split record id separated by comma into array
		$arr_rec_id = array_map('trim', explode(",", $rec_id));
		$db->where("drainage_noc_jal_oc.id", $arr_rec_id, "in");
		$bool = $db->delete($tablename);
		if($bool){
			$this->set_flash_msg("Record deleted successfully", "success");
		}
		elseif($db->getLastError()){
			$page_error = $db->getLastError();
			$this->set_flash_msg($page_error, "danger");
		}
		return	$this->redirect("drainage_noc_jal_oc");
	}
	/**
     * View record detail 
	 * @param $rec_id (select record by table primary key) 
     * @param $value value (select record by value of field name(rec_id))
     * @return BaseView
     */
	function cert_view($rec_id = null, $value = null){
		$request = $this->request;
		$db = $this->GetModel();
		$rec_id = $this->rec_id = urldecode($rec_id);
		$tablename = $this->tablename;
		$fields = array("id", 
			"application_type_id", 
			"application_type_value", 
			"applicant_surname", 
			"applicant_name", 
			"applicant_father_or_spouse_name", 
			"title", 
			"house_building_society_name", 
			"house_or_block_number", 
			"wing", 
			"floor", 
			"road_name", 
			"place_or_division_or_village", 
			"taluka", 
			"pincode", 
			"zone_id", 
			"zone_value", 
			"election_ward_no_id", 
			"election_ward_no_value", 
			"mobile_no", 
			"email", 
			"title_property", 
			"property_type_id", 
			"property_type_value", 
			"computarized_property_no", 
			"title_for_application_related_information", 
			"property_survey_no_or_city_survey_no", 
			"mouje_gaon_name", 
			"road_name_for_property", 
			"place_division_gaon_for_property", 
			"pincode_for_property", 
			"zone_property_id", 
			"zone_property_value", 
			"property_type_as_per_application_id", 
			"property_type_as_per_application_value", 
			"is_construction_commence_ceriticate_available", 
			"commence_ceriticate_number", 
			"commence_ceriticate_date", 
			"property_usage", 
			"property_usage_type_id", 
			"property_usage_type_value", 
			"upload_architech_affidavit", 
			"upload_construction_permission_and_cerified_map_copy", 
			"upload_architect_or_project_consultant_report", 
			"upload_property_location_map", 
			"upload_noc_copy_given_for_construction_permission", 
			"upload_map_prepared_by_licensed_plumber", 
			"rec_id", 
			"user_id", 
			"date", 
			"architect_name", 
			"hissa_number", 
			"timestamp", 
			"status", 
			"certificate", 
			"paid", 
			"property_taluka", 
			"upload_mep_consultant_or_architect_declaration", 
			"application_no", 
			"demand", 
			"inspection", 
			"commencement_number", 
			"upload_cc_certificate");
		if($value){
			$db->where($rec_id, urldecode($value)); //select record based on field name
		}
		else{
			$db->where("drainage_noc_jal_oc.id", $rec_id);; //select record based on primary key
		}
		$record = $db->getOne($tablename, $fields );
		if($record){
			$record['date'] = human_date($record['date']);
// $record['timestamp'] = human_datetime($record['timestamp']);
			$page_title = $this->view->page_title = "View  Drainage Noc Jal Oc";
		$this->view->report_filename = date('Y-m-d') . '-' . $page_title;
		$this->view->report_title = $page_title;
		$this->view->report_layout = "report_layout.php";
		$this->view->report_paper_size = "A4";
		$this->view->report_orientation = "portrait";
		}
		else{
			if($db->getLastError()){
				$this->set_page_error();
			}
			else{
				$this->set_page_error("No record found");
			}
		}
		return $this->render_view("drainage_noc_jal_oc/cert_view.php", $record);
	}
}
